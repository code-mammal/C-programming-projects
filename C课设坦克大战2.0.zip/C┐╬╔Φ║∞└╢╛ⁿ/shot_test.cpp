#include "redblue.h"


void shot_test(struct object *pobj,unsigned *pr_score,unsigned *pb_score)
{
    int i,j;
    for(i=0; i<OBJ_NUM; i++)
    {
        for(j=0; j<OBJ_NUM; j++)
        {
            if(j==i)continue;
            if( abs(pobj[i].bullet.x-pobj[j].tank.x)<(pobj[i].bullet.bltwidth/2+pobj[j].tank.tkwidth/2)&&abs(pobj[i].bullet.y-pobj[j].tank.y)<(pobj[i].bullet.bltheight/2+pobj[j].tank.tkheight/2)&&pobj[i].bullet.shot!=0)
            {
                if(pobj[i].tank.color!=pobj[j].tank.color)
                {
                    if(pobj[i].tank.color==COLOR_RED)
                        if(pobj[j].tank.control==0)
                            *pr_score+=LAG_SCORE;
                        else
                            *pr_score+=SML_SCORE;

                    else
                        if(pobj[j].tank.control==0)
                            *pb_score+=LAG_SCORE;
                        else
                            *pb_score+=SML_SCORE;

                  pobj[j].tank.life=0;

                }
                pobj[i].bullet.shot=0;
            }
        }
        for(j=i+1; j<OBJ_NUM; j++)
        {
            if( abs(pobj[i].bullet.x-pobj[j].bullet.x)<(pobj[i].bullet.bltwidth/2+pobj[j].bullet.bltwidth/2)&&abs(pobj[i].bullet.y-pobj[j].bullet.y)<(pobj[i].bullet.bltheight/2+pobj[j].bullet.bltheight/2) &&pobj[i].bullet.shot!=0&&pobj[j].bullet.shot!=0)
                pobj[i].bullet.shot=pobj[j].bullet.shot=0;
        }
    }
}
