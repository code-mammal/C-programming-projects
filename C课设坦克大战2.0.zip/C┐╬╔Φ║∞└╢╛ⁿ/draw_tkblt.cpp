#include "redblue.h"
void draw_tkblt(struct object *pobj,PIMAGE *ptank,PIMAGE *pbullet)
{
    int i;
    for(i=0;i<OBJ_NUM;i++)
    {
        if(pobj[i].tank.color==COLOR_RED)
            switch(pobj[i].tank.direction)
            {
            case d_UP:
            putimage_transparent(NULL,ptank[0],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_RIGHT:
            putimage_transparent(NULL,ptank[1],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_DOWN:
            putimage_transparent(NULL,ptank[2],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_LEFT:
            putimage_transparent(NULL,ptank[3],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            }

        else
            switch(pobj[i].tank.direction)
            {
            case d_UP:
            putimage_transparent(NULL,ptank[4],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_RIGHT:
            putimage_transparent(NULL,ptank[5],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_DOWN:
            putimage_transparent(NULL,ptank[6],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_LEFT:
            putimage_transparent(NULL,ptank[7],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            }

        switch(pobj[i].bullet.direction)
            {
            case d_UP:
            putimage_transparent(NULL,pbullet[0],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;

            case d_RIGHT:
            putimage_transparent(NULL,pbullet[1],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;

            case d_DOWN:
            putimage_transparent(NULL,pbullet[2],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;

            case d_LEFT:
            putimage_transparent(NULL,pbullet[3],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;
            }

    }
}
