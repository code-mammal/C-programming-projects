#include "redblue.h"

void playertank_act(struct object*pobj,PIMAGE *ptank,PIMAGE *pbullet)
{
    int i,skey=0;
    for(i=0;i<OBJ_NUM;i++)
    {
        if(pobj[i].tank.control==0)
        while(kbhit())
        {
            int key=getch();
            if(key==key_0)
            {
                while(1)
                {
                    if(kbhit())
                        skey=getch();
                    if(skey==key_0)
                        break;
                }
            }

            switch(key)
            {
            case key_8:
                if(pobj[i].tank.direction!=d_UP)
                {
                    pobj[i].tank.direction=d_UP;
                    break;
                }
                if(pobj[i].tank.y>=(pobj[i].tank.tkspeed+pobj[i].tank.tkheight/2)&&pobj[i].tank.y<=(HEIGHT-pobj[i].tank.tkheight/2))
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.y-=pobj[i].tank.tkspeed;
                break;

            case key_6:
                if(pobj[i].tank.direction!=d_RIGHT)
                {
                    pobj[i].tank.direction=d_RIGHT;
                    break;
                }
                if(pobj[i].tank.x>=(pobj[i].tank.tkwidth/2)&&pobj[i].tank.x<=(WIDTH-S_WIDTH-pobj[i].tank.tkspeed-pobj[i].tank.tkwidth/2))
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.x+=pobj[i].tank.tkspeed;
                break;

            case key_2:
                if(pobj[i].tank.direction!=d_DOWN)
                {
                    pobj[i].tank.direction=d_DOWN;
                    break;
                }
                if(pobj[i].tank.y>=(pobj[i].tank.tkheight/2)&&pobj[i].tank.y<=(HEIGHT-pobj[i].tank.tkspeed-pobj[i].tank.tkheight/2))
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.y+=pobj[i].tank.tkspeed;
                break;

            case key_4:
                if(pobj[i].tank.direction!=d_LEFT)
                {
                    pobj[i].tank.direction=d_LEFT;
                    break;
                }
                if(pobj[i].tank.x>=(pobj[i].tank.tkspeed+pobj[i].tank.tkwidth/2)&&pobj[i].tank.x<=(WIDTH-S_WIDTH-pobj[i].tank.tkwidth/2))
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.x-=pobj[i].tank.tkspeed;
                break;

            case key_space:
                if(pobj[i].bullet.shot==0)
                {
                    pobj[i].bullet.shot=1;
                    PlaySound(TEXT("..\\Res\\hit.WAV"),NULL,SND_FILENAME|SND_ASYNC);
                    switch(pobj[i].tank.direction)
                    {
                    case d_UP:
                        pobj[i].bullet.direction=d_UP;
                        pobj[i].bullet.x=pobj[i].tank.x;
                        pobj[i].bullet.y=pobj[i].tank.y-(pobj[i].tank.tkheight/2+pobj[i].bullet.bltheight/2);
                        break;

                    case d_DOWN:
                        pobj[i].bullet.direction=d_DOWN;
                        pobj[i].bullet.x=pobj[i].tank.x;
                        pobj[i].bullet.y=pobj[i].tank.y+(pobj[i].tank.tkheight/2+pobj[i].bullet.bltheight/2);
                        break;

                    case d_LEFT:
                        pobj[i].bullet.direction=d_LEFT;
                        pobj[i].bullet.x=pobj[i].tank.x-(pobj[i].tank.tkwidth/2+pobj[i].bullet.bltwidth/2);
                        pobj[i].bullet.y=pobj[i].tank.y;
                        break;

                    case d_RIGHT:
                        pobj[i].bullet.direction=d_RIGHT;
                        pobj[i].bullet.x=pobj[i].tank.x+(pobj[i].tank.tkwidth/2+pobj[i].bullet.bltwidth/2);
                        pobj[i].bullet.y=pobj[i].tank.y;
                        break;
                    }

                }
            }
        }

        fflush(stdin);
    }
}
