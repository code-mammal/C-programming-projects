#include "redblue.h"


void AItank_act(struct object *pobj,PIMAGE *ptank,PIMAGE *pbullet)
{
    int i;
    for(i=0;i<OBJ_NUM;i++)
    if(pobj[i].tank.control==1)
        {
            if(pobj[i].tank.life==0)
            {
                pobj[i].tank.x=pobj[i].tank.x0;
                pobj[i].tank.y=pobj[i].tank.y0;
                pobj[i].tank.life=1;
                continue;
            }

            unsigned int direct=random(RAND_NUM);
            if (direct==0||direct==1)
                {
                    if(pobj[i].tank.direction!=d_UP)
                    {
                        pobj[i].tank.direction=d_UP;
                    }
                }

            else if (direct==2||direct==3)
                {
                    if(pobj[i].tank.direction!=d_RIGHT)
                    {
                        pobj[i].tank.direction=d_RIGHT;
                    }
                }

            else if (direct==4||direct==5)
                {
                    if(pobj[i].tank.direction!=d_DOWN)
                    {
                        pobj[i].tank.direction=d_DOWN;
                    }
                }

            else if (direct==6||direct==7)
                {
                    if(pobj[i].tank.direction!=d_LEFT)
                    {
                        pobj[i].tank.direction=d_LEFT;
                    }
                }

            else if (direct==8)
                {
                    if(pobj[i].bullet.shot==0)
                    {
                        pobj[i].bullet.shot=1;
                        switch(pobj[i].tank.direction)
                        {
                            case d_UP:
                            pobj[i].bullet.direction=d_UP;
                            pobj[i].bullet.x=pobj[i].tank.x;
                            pobj[i].bullet.y=pobj[i].tank.y-(pobj[i].tank.tkheight/2+pobj[i].bullet.bltheight/2);
                            break;
                            case d_DOWN:
                            pobj[i].bullet.direction=d_DOWN;
                            pobj[i].bullet.x=pobj[i].tank.x;
                            pobj[i].bullet.y=pobj[i].tank.y+(pobj[i].tank.tkheight/2+pobj[i].bullet.bltheight/2);
                            break;
                            case d_LEFT:
                            pobj[i].bullet.direction=d_LEFT;
                            pobj[i].bullet.x=pobj[i].tank.x-(pobj[i].tank.tkwidth/2+pobj[i].bullet.bltwidth/2);
                            pobj[i].bullet.y=pobj[i].tank.y;
                            break;
                            case d_RIGHT:
                            pobj[i].bullet.direction=d_RIGHT;
                            pobj[i].bullet.x=pobj[i].tank.x+(pobj[i].tank.tkwidth/2+pobj[i].bullet.bltwidth/2);
                            pobj[i].bullet.y=pobj[i].tank.y;
                            break;
                        }
                    }
                }
            else
            {
                if(pobj[i].tank.y>=(pobj[i].tank.tkheight/2+pobj[i].tank.tkspeed)&&pobj[i].tank.y<=(HEIGHT-pobj[i].tank.tkheight/2)&&pobj[i].tank.direction==d_UP)
                   {
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.y-=pobj[i].tank.tkspeed;
                   }

                else if(pobj[i].tank.x>=(pobj[i].tank.tkwidth/2)&&pobj[i].tank.x<=(WIDTH-S_WIDTH-pobj[i].tank.tkwidth/2-pobj[i].tank.tkspeed)&&pobj[i].tank.direction==d_RIGHT)
                    {
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.x+=pobj[i].tank.tkspeed;
                    }

                else if(pobj[i].tank.y>=(pobj[i].tank.tkheight/2)&&pobj[i].tank.y<=(HEIGHT-pobj[i].tank.tkheight/2-pobj[i].tank.tkspeed)&&pobj[i].tank.direction==d_DOWN)
                    {
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.y+=pobj[i].tank.tkspeed;
                    }
                else if(pobj[i].tank.x>=(pobj[i].tank.tkwidth/2+pobj[i].tank.tkspeed)&&pobj[i].tank.x<=(WIDTH-S_WIDTH-pobj[i].tank.tkwidth/2)&&pobj[i].tank.direction==d_LEFT)
                    {
                    if(tkcrash_test(i,&pobj[i],pobj)==0)
                        pobj[i].tank.x-=pobj[i].tank.tkspeed;
                    }

                else ;

            }
        }

}
