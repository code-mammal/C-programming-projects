#include "redblue.h"

void loadimage(PIMAGE *ptank,PIMAGE *pbullet,PIMAGE * pbomb)
{
    int i;
    for(i=0;i<TK_IMGNUM;i++)
        ptank[i]=newimage();

    for(i=0;i<BLT_IMGNUM;i++)
        pbullet[i]=newimage();


    getimage(ptank[0],"..\\Res\\tkrup.bmp");
    getimage(ptank[1],"..\\Res\\tkrright.bmp");
    getimage(ptank[2],"..\\Res\\tkrdown.bmp");
    getimage(ptank[3],"..\\Res\\tkrleft.bmp");

    getimage(ptank[4],"..\\Res\\tkgup.bmp");
    getimage(ptank[5],"..\\Res\\tkgright.bmp");
    getimage(ptank[6],"..\\Res\\tkgdown.bmp");
    getimage(ptank[7],"..\\Res\\tkgleft.bmp");

    getimage(pbullet[0],"..\\Res\\bltup.bmp");
    getimage(pbullet[1],"..\\Res\\bltright.bmp");
    getimage(pbullet[2],"..\\Res\\bltdown.bmp");
    getimage(pbullet[3],"..\\Res\\bltleft.bmp");

    getimage(*pbomb,"..\\Res\\bomb.bmp");

}
