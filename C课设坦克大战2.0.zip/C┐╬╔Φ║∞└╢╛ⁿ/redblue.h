#ifndef REDBLUE_H_INCLUDED
#define REDBLUE_H_INCLUDED


#endif // REDBLUE_H_INCLUDED

#include "graphics.h"
#include "stdio.h"
#include "windows.h"
#include "math.h"
#include "stdlib.h"
#include "conio.h"
#include<mmsystem.h>
//#pragma comment(lib, "WINMM.LIB")


#define  WIDTH  1000
#define  HEIGHT  800
#define  S_WIDTH 200

#define  OBJ_NUM  6
#define  TK_IMGNUM  8
#define  BLT_IMGNUM  4

#define  RAND_NUM  100

#define  PL_TKSPEED 10
#define  AI_TKSPEED 5
#define  BLTSPEED 15

#define  SML_SCORE  10
#define  LAG_SCORE  30

#define  FPS  60

#define  ANIMA_TIME  5000


void init_object(struct object*pobj,PIMAGE *ptank,PIMAGE *pbullet);       //��ʼ��̹�ˡ��ӵ�

void mainloop(unsigned *pr_score,unsigned *pb_score);

void playertank_act(struct object*pobj,PIMAGE *ptank,PIMAGE *pbullet);

void update_pos(struct object* pobj,PIMAGE *ptank,PIMAGE *pbullet,unsigned *pr_score,unsigned *pb_score);       //����̹�ˡ��ӵ�����

void draw_obj(struct object*pobj,unsigned *pr_score,unsigned *pb_score,PIMAGE *pbomb,PIMAGE *ptank,PIMAGE *pbullet);          //��̹�ˡ��ӵ�

void shot_test(struct object *pobj,unsigned *pr_score,unsigned *pb_score);        //�ӵ��ӵ����ӵ�̹����ײ���

void first_window(void);                     //��������

void first_anima(void);

void end_anima(unsigned *pr_score,unsigned *pb_score);                       //��������

void AItank_act(struct object *pobj,PIMAGE *ptank,PIMAGE *pbullet);

void release_img(PIMAGE *ptank,PIMAGE *pbullet,PIMAGE *pbomb);      //ͼ��ָ���ͷ�

void bullet_move(struct object *pobj);

void loadimage(PIMAGE *ptank,PIMAGE *pbullet,PIMAGE *pbomb);

int tkcrash_test(int k,struct object *pnow,struct object *phead);

void draw_tkblt(struct object *pobj,PIMAGE *ptank,PIMAGE *pbullet);

enum direction {d_UP=0,d_LEFT,d_DOWN,d_RIGHT};
enum color {COLOR_RED=0,COLOR_BLUE};

struct tank
{
    int x0,y0;          //̹�˳�ʼ���꣨��ʼ�������󸴻
    int x,y;            //̹�˵�ǰ����
    int direction;      //����
    int control;        //ϵͳ����ҿ���
    int color;
    int tkspeed;
    int life;           //����
    int tkheight;
    int tkwidth;

};
struct bullet
{
    int x,y;            //�ӵ���ǰ����
    int direction;      //����
    int shot;           //����״̬
    int bltspeed;
    int bltheight;
    int bltwidth;
};

struct object
{
    struct tank tank;
    struct bullet bullet;
};


