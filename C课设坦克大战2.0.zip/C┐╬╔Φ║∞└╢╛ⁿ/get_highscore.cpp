#include "redblue.h"

unsigned int get_highscore(void)
{
    FILE *fp;
    unsigned highest_score;

    if((fp=fopen("..\\Res\\record.txt","rt"))==NULL)
    {
        outtextxy(getwidth()/2,getheight()/2,"���ܴ���Ӧ�ļ���");
        exit(1);
    }

    fscanf(fp,"%d",&highest_score);

    fclose(fp);

    return highest_score;
}
