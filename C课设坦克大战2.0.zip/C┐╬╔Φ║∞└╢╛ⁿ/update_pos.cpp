#include "redblue.h"

void update_pos(struct object* pobj,PIMAGE *ptank,PIMAGE *pbullet,unsigned *pr_score,unsigned *pb_score)
{
    playertank_act(pobj,ptank,pbullet);

    AItank_act(pobj,ptank,pbullet);

    bullet_move(pobj);

    cleardevice();

    draw_tkblt(pobj,ptank,pbullet);

    shot_test(pobj,pr_score,pb_score);

}
