#include "redblue.h"


void bullet_move(struct object *pobj)
{
    int i;
    for(i=0; i<OBJ_NUM; i++)
        if(pobj[i].bullet.shot)
            switch(pobj[i].bullet.direction)
            {
            case d_UP:
                if(pobj[i].bullet.y>=(pobj[i].bullet.bltspeed+pobj[i].bullet.bltheight/2)&&pobj[i].bullet.y<=(WIDTH-S_WIDTH-pobj[i].bullet.bltheight/2))
                    pobj[i].bullet.y-=pobj[i].bullet.bltspeed;
                else
                    pobj[i].bullet.shot=0;
                break;

            case d_DOWN:
                if(pobj[i].bullet.y>=(pobj[i].bullet.bltheight/2)&&pobj[i].bullet.y<=(WIDTH-S_WIDTH-pobj[i].bullet.bltspeed-pobj[i].bullet.bltheight/2))
                    pobj[i].bullet.y+=pobj[i].bullet.bltspeed;
                else
                    pobj[i].bullet.shot=0;
                break;

            case d_RIGHT:
                if(pobj[i].bullet.x>=(pobj[i].bullet.bltwidth/2)&&pobj[i].bullet.x<=(WIDTH-S_WIDTH-pobj[i].bullet.bltspeed-pobj[i].bullet.bltwidth/2))
                    pobj[i].bullet.x+=pobj[i].bullet.bltspeed;
                else
                    pobj[i].bullet.shot=0;
                break;

            case d_LEFT:
                if(pobj[i].bullet.x>=(pobj[i].bullet.bltspeed+pobj[i].bullet.bltwidth/2)&&pobj[i].bullet.x<=(WIDTH-S_WIDTH-pobj[i].bullet.bltwidth/2))
                    pobj[i].bullet.x-=pobj[i].bullet.bltspeed;
                else
                    pobj[i].bullet.shot=0;
                break;
            }
}
