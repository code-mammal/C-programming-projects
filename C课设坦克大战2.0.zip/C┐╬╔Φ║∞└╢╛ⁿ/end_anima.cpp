#include "redblue.h"


void end_anima(unsigned *pr_score,unsigned *pb_score)
{
    cleardevice();
    PlaySound(TEXT("..\\Res\\end.WAV"),NULL,SND_FILENAME|SND_ASYNC);
    int maxx=getwidth();
    PIMAGE pimg=newimage();
    getimage(pimg,"..\\Res\\end1.png");
    putimage_transparent(NULL,pimg,200,200,BLACK);
    delimage(pimg);


    setcolor(WHITE);
    setfontbkcolor(BLUE);
    setbkmode(TRANSPARENT);
    char c[32];
    sprintf(c,"Red %d:%d Blue ",*pr_score,*pb_score);

    setfont(48,0,"宋体");
    outtextxy(maxx/2,400,c);

    if(*pr_score>*pb_score)
        outtextxy(maxx/2,500,"Congratulation! How smart you are!");
    else if(*pr_score<*pb_score)
        outtextxy(maxx/2,500,"Don't lose heart,keep on going.");
    else
        outtextxy(maxx/2,500,"A draw...");

    setfont(16,0,"宋体");
    outtextxy(maxx/2,600,"Press enter to restart or esc to exit...");
    //delay_ms(DELAY_TIME);

}
