#include "redblue.h"



int main()       //���2������ʱ��̹����ײ���ı䷽��
{

    setinitmode(INIT_ANIMATION);

    setcaption("̹�˴�սDEMO");

    initgraph(WIDTH,HEIGHT);

    first_window();


    while(1)
    {
        first_anima();
        unsigned red_score=0;
        unsigned *pr_score=&red_score;

        unsigned blue_score=0;
        unsigned *pb_score=&blue_score;

        mainloop(pr_score,pb_score);

        end_anima(pr_score,pb_score);

        while(1)
        {
            int k=getch();
            if(k==key_esc)
                exit(0);
            else if(k==key_enter)
                break;
        }
    }

    // �رջ�ͼ�豸
    closegraph();

    return 0;

}










