#include "redblue.h"

void set_highscore(unsigned *pscore)
{
    FILE *fp;

    if((fp=fopen("..\\Res\\record.txt","wt"))==NULL)
    {
        outtextxy(getwidth()/2,getheight()/2,"���ܴ���Ӧ�ļ���");
        exit(1);
    }

    fprintf(fp,"%d",int(*pscore));

    fclose(fp);
}
