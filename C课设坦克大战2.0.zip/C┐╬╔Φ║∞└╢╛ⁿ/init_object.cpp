#include "redblue.h"


void init_object(struct object*pobj,PIMAGE *ptank,PIMAGE *pbullet)   //̹��ͼ�������ʼ��
{
    int tkwidth=getwidth(ptank[0]);   //�õ�̹�ˡ��ӵ��ĳ���
    int tkheight=getheight(ptank[0]);

    int bltwidth=getwidth(pbullet[0]);
    int bltheight=getheight(pbullet[0]);

    int i;
    for(i=0; i<OBJ_NUM; i++)
    {

        pobj[i].tank.tkwidth=tkwidth;        //���ó���
        pobj[i].tank.tkheight=tkheight;

        pobj[i].bullet.bltwidth=bltwidth;
        pobj[i].bullet.bltheight=bltheight;

        if(i!=0/*&&i!=OBJ_NUM-1*/)
        {
            pobj[i].tank.tkspeed=AI_TKSPEED;
            pobj[i].tank.control=1;
        }

        pobj[i].bullet.bltspeed=BLTSPEED;

        pobj[i].bullet.shot=0;
        pobj[i].tank.life=1;

        if(i%2==0)
        {
            pobj[i].tank.direction=d_DOWN;
            pobj[i].tank.color=COLOR_RED;

            pobj[i].tank.x=pobj[i].tank.x0=(((WIDTH-S_WIDTH)/2-tkwidth/2)*i/2+tkwidth/2);
            pobj[i].tank.y=pobj[i].tank.y0=tkheight/2;
        }
        else
        {
            pobj[i].tank.direction=d_UP;
            pobj[i].tank.color=COLOR_BLUE;

            pobj[i].tank.x=pobj[i].tank.x0=(((WIDTH-S_WIDTH)/2-tkwidth/2)*(i-1)/2+tkwidth/2);
            pobj[i].tank.y=pobj[i].tank.y0=HEIGHT-tkheight/2;
        }

    }

    pobj[0].tank.control=0;

    pobj[0].tank.tkspeed=PL_TKSPEED;

    //pobj[OBJ_NUM-1].tank.control=0;

    //pobj[OBJ_NUM-1].tank.tkspeed=PL_TKSPEED;



}
