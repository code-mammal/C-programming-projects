#include "redblue.h"

int tkcrash_test(int k,struct object *pnow,struct object *phead)
{
    int i;
    switch(pnow->tank.direction)
    {
        case d_UP:
        for(i=0;i<OBJ_NUM;i++)
        {
            if(k==i)continue;
            if(phead[i].tank.y>pnow->tank.y&&(phead[i].tank.y-pnow->tank.y)<(pnow->tank.tkheight/2+phead[i].tank.tkheight/2+pnow->tank.tkspeed)&&(abs(pnow->tank.x-phead[i].tank.x)<(pnow->tank.tkwidth/2+phead[i].tank.tkwidth/2)))
            return 1;
        }

        case d_DOWN:
        for(i=0;i<OBJ_NUM;i++)
        {
            if(k==i)continue;
            if(pnow->tank.y>phead[i].tank.y&&(pnow->tank.y-phead[i].tank.y)<(pnow->tank.tkheight/2+phead[i].tank.tkheight/2+pnow->tank.tkspeed)&&(abs(pnow->tank.x-phead[i].tank.x)<(pnow->tank.tkwidth/2+phead[i].tank.tkwidth/2)))
            return 1;
        }

        case d_RIGHT:
        for(i=0;i<OBJ_NUM;i++)
        {
            if(k==i)continue;
            if(phead[i].tank.x>pnow->tank.x&&(phead[i].tank.x-pnow->tank.x)<(pnow->tank.tkwidth/2+phead[i].tank.tkwidth/2+pnow->tank.tkspeed)&&(abs(pnow->tank.y-phead[i].tank.y)<(pnow->tank.tkheight/2+phead[i].tank.tkheight/2)))
            return 1;
        }

        case d_LEFT:
        for(i=0;i<OBJ_NUM;i++)
        {
            if(k==i)continue;
            if(pnow->tank.x>phead[i].tank.x&&(pnow->tank.x-phead[i].tank.x)<(pnow->tank.tkwidth/2+phead[i].tank.tkwidth/2+pnow->tank.tkspeed)&&(abs(pnow->tank.y-phead[i].tank.y)<(pnow->tank.tkheight/2+phead[i].tank.tkheight/2)))
            return 1;
        }

    }

    return 0;

}
