#include "redblue.h"

void mainloop(unsigned *pr_score,unsigned *pb_score)
{
    struct object object[OBJ_NUM];
    PIMAGE ptank[TK_IMGNUM];
    PIMAGE pbullet[BLT_IMGNUM];

    PIMAGE bomb=newimage();
    PIMAGE * pbomb=&bomb;

    loadimage(ptank,pbullet,pbomb);

    init_object(&object[0],ptank,pbullet);

    for ( ; is_run(); delay_fps(FPS))
    {
        randomize();

        update_pos(&object[0],ptank,pbullet,pr_score,pb_score);

        cleardevice();

        draw_obj(&object[0],pr_score,pb_score,pbomb,ptank,pbullet);

        if(object[0].tank.life==0)break;
    }

    release_img(ptank,pbullet,pbomb);
}
