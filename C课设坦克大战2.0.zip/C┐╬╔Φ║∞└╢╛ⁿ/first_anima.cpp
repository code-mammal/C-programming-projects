#include "redblue.h"

void first_anima(void)
{
    cleardevice();

    setfont(36,0,"����");
    setcolor(WHITE);
    settextjustify(CENTER_TEXT,CENTER_TEXT);

    outtextxy(getwidth()/2,getheight()/2-50,"You are red,and AI is blue ...");
    outtextxy(getwidth()/2,getheight()/2+50,"Improve your skill to defeat AI!");
    PlaySound(TEXT("..\\Res\\start.WAV"),NULL,SND_FILENAME|SND_ASYNC);

    delay_ms(ANIMA_TIME);

}
