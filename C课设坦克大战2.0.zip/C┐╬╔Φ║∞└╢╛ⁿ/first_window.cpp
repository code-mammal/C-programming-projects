#include "redblue.h"

void first_window(void)
{
    PIMAGE pimg=newimage();
    getimage(pimg,"..\\Res\\first1.png");
    putimage_transparent(NULL,pimg,200,200,BLACK);

    setcolor(WHITE);
    setfont(20,0,"����");
    settextjustify(CENTER_TEXT,CENTER_TEXT);
    outtextxy(WIDTH/2,HEIGHT/2,"Press enter to start or esc to exit");

    delimage(pimg);

    while(1)
    {
        int key=getch();

        if(key==key_enter)
            break;

        if(key==key_esc)
            exit(0);
    }

}
