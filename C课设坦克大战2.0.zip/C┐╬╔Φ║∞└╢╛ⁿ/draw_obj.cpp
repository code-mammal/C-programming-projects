#include "redblue.h"

void draw_obj(struct object *pobj,unsigned *pr_score,unsigned *pb_score,PIMAGE *pbomb,PIMAGE *ptank,PIMAGE *pbullet)
{

    char c[32];
    setfillcolor(LIGHTGRAY);
    bar(WIDTH-S_WIDTH,0,WIDTH,HEIGHT);
    setfont(16,0,"����");
    setcolor(BLACK);
    setfontbkcolor(LIGHTRED);
    setbkmode(TRANSPARENT);
    outtextxy(900,200,"���:С����2468�ƶ�");
    outtextxy(900,220,"�ո�������ӵ�");
    outtextxy(900,240,"����0��ͣ/����");
    outtextxy(900,300,"�������+30,����AI+10");

    sprintf(c,"Red %d:%d Blue",*pr_score,*pb_score);
    outtextxy(900,400,c);

    int i;
    for(i=0; i<OBJ_NUM; i++)
    {
        if(pobj[i].bullet.shot==1)
        switch(pobj[i].bullet.direction)
            {
            case d_UP:
            putimage_transparent(NULL,pbullet[0],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;

            case d_RIGHT:
            putimage_transparent(NULL,pbullet[1],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;

            case d_DOWN:
            putimage_transparent(NULL,pbullet[2],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;

            case d_LEFT:
            putimage_transparent(NULL,pbullet[3],pobj[i].bullet.x-pobj[i].bullet.bltwidth/2,pobj[i].bullet.y-pobj[i].bullet.bltheight/2,BLACK);
            break;
            }


        if(pobj[i].tank.life==0)
        {
            putimage_transparent(NULL,*pbomb,pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            if(pobj[i].tank.control==1)
            PlaySound(TEXT("..\\Res\\bomb.WAV"),NULL,SND_FILENAME|SND_ASYNC);
        }
        else
        {
            if(pobj[i].tank.color==COLOR_RED)
            switch(pobj[i].tank.direction)
            {
            case d_UP:
            putimage_transparent(NULL,ptank[0],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_RIGHT:
            putimage_transparent(NULL,ptank[1],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_DOWN:
            putimage_transparent(NULL,ptank[2],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_LEFT:
            putimage_transparent(NULL,ptank[3],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            }

            else
            switch(pobj[i].tank.direction)
            {
            case d_UP:
            putimage_transparent(NULL,ptank[4],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_RIGHT:
            putimage_transparent(NULL,ptank[5],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_DOWN:
            putimage_transparent(NULL,ptank[6],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            case d_LEFT:
            putimage_transparent(NULL,ptank[7],pobj[i].tank.x-pobj[i].tank.tkwidth/2,pobj[i].tank.y-pobj[i].tank.tkheight/2,BLACK);
            break;

            }
        }

    }
}
