#include "redblue.h"

void release_img(PIMAGE *ptank,PIMAGE *pbullet,PIMAGE *pbomb)
{
    int i;

    for(i=0;i<TK_IMGNUM;i++)
        delimage(ptank[i]);

    for(i=0;i<BLT_IMGNUM;i++)
        delimage(pbullet[i]);

    delimage(*pbomb);
}
